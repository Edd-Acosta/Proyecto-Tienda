<?php
$conexion = new mysqli ("fdb1030.awardspace.net","4583275_hospital","quesadilla94","4583275_hospital");
if ($conexion) {
}else{
    echo "Error de conexion";
}

?>